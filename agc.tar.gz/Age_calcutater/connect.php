<?php
    include_once("conn.php");

    $day = $_Post['day'];
    $month = $_post['month'];
    $year = $_post['year'];

